﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Tiled2Unity
{
    public class ObjectLayer : Tiled2Unity.Layer
    {
        public Color Color;
    }
}
